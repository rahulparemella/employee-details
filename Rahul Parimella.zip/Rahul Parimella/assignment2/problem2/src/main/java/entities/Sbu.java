package entities;

public class Sbu {
	private String sbuCode;
	private String sbuHead;
	private String sbuName;
	@Override
	public String toString() {
		return "sbu details= Sbu [sbuCode=" + sbuCode + ", sbuHead=" + sbuHead + ", sbuName=" + sbuName + "]";
	}
	public Sbu() {
		super();
	}
	public String getSbu() {
		return sbuCode;
	}
	public void setSbuCode(String sbuCode) {
		this.sbuCode = sbuCode;
	}
	public String getSbuHead() {
		return sbuHead;
	}
	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}
	public String getSbuName() {
		return sbuName;
	}
	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}
}