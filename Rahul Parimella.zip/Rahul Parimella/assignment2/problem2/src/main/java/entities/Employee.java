package entities;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

@SuppressWarnings("deprecation")
public class Employee {
	private int EmployeeId;
	private  String EmployeeName;
	private  double Salary;
	private String businessunit;
	private int Age;
	public int getEmployeeId() {
		return EmployeeId;
	}
	public void setEmployeeId(int employeeId) {
		EmployeeId = employeeId;
	}
	public String getEmployeeName() {
		return EmployeeName;
	}
	public void setEmployeeName(String employeeName) {
		EmployeeName = employeeName;
	}
	public double getSalary() {
		return Salary;
	}
	public void setSalary(int salary) {
		Salary = salary;
	}
	public String getBusinessunit() {
		return businessunit;
	}
	public void setBusinessunit(String businessunit) {
		this.businessunit = businessunit;
	}
	public int getAge() {
		return Age;
	}
	public void setAge(int age) {
		Age = age;
	}
	
	
	
	public void showResult() {
		System.out.println("Employee details");
		System.out.println("-----------------");
		 System.out.println("Employee [EmployeeId=" + EmployeeId + ", EmployeeName=" + EmployeeName + ", Salary=" + Salary
				+ ", businessunit=" + businessunit + ", Age=" + Age + "]");
	}
	public void getSbuDetails()
	{
		BeanFactory context = new XmlBeanFactory(new ClassPathResource("rahul2.xml"));
		Sbu emp = (Sbu)context.getBean("Sbu");
		System.out.println(emp);
	}
}
