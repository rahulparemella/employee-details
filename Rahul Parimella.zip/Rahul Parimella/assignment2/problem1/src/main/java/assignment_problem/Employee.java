package assignment_problem;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Employee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context=new ClassPathXmlApplicationContext("a.xml");
		Employee_Details emp=context.getBean("employee",Employee_Details.class);
		emp.display();
	}

}
