package com.cg.onlinetestmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlinetestmanagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlinetestmanagementApplication.class, args);
	}

}
