package main;


import org.springframework.beans.factory.BeanFactory;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import com.setterinjection.*;
public class app {
	public static void main(String[] args) {


		BeanFactory context = new XmlBeanFactory(new ClassPathResource("rahul.xml"));
		Employee emp1 = (Employee)context.getBean("em1");
		Employee emp2 = (Employee)context.getBean("em2");
		emp2.getSbuDetails();

}
}
