package assignment_problem;

public class Employee_Details {
	private int EmpId;
	private String EmpName;
	private int EmpAge;
	private int EmpSal;
	private String BusinessUnit;
	public int getEmpId() {
		return EmpId;
	}
	public void setEmpId(int empId) {
		EmpId = empId;
	}
	public String getEmpName() {
		return EmpName;
	}
	public void setEmpName(String empName) {
		EmpName = empName;
	}
	public int getEmpAge() {
		return EmpAge;
	}
	public void setEmpAge(int empAge) {
		EmpAge = empAge;
	}
	public int getEmpSal() {
		return EmpSal;
	}
	public void setEmpSal(int empSal) {
		EmpSal = empSal;
	}
	public String getBusinessUnit() {
		return BusinessUnit;
	}
	public void setBusinessUnit(String businessUnit) {
		BusinessUnit = businessUnit;
	}
	public void display() {
		System.out.println("Employee Details:");
		System.out.println("------------------");
		System.out.println("Employee ID:"+EmpId);
		System.out.println("Employee Name:"+EmpName);
		System.out.println("Employee Age:"+EmpAge);
		System.out.println("Employee Salary:"+EmpSal);
		System.out.println("Employee BU:"+BusinessUnit);
	}
}
