# Employee Management 

## Problem Statement 1.5
Implement the above lab using Javabase configuration and Spring Boot Features.
