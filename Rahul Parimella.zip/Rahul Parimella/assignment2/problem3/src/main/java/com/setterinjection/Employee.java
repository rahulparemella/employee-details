package com.setterinjection;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
public class Employee {
	private int ids;
	private String name;
	private double salary;
	private String bu;
	private int age;
	public String getBu() {
		return bu;
	}
	public void getSbuDetails()
	{
		BeanFactory context = new XmlBeanFactory(new ClassPathResource("rahul.xml"));
		Sbu emp = (Sbu)context.getBean("sbu1");
		System.out.println("SBU="+emp);
	}
	public void setBu(String bu) {
		this.bu = bu;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	@Override
	public String toString() {
		return "Employee [ids=" + ids + ", name=" + name + ", salary=" + salary + ", bu=" + bu + ", age=" + age + "]";
	}
	public Employee() {
		super();
	}
	public int getIds() {
		return ids;
	}
	public void setIds(int ids) {
		this.ids = ids;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
}