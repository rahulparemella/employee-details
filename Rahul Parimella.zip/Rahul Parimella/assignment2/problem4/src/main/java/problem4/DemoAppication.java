package problem4;

import java.util.List;

import java.util.Scanner;
import java.util.stream.Collectors;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class DemoAppication {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("rahul4.xml");
		Sbu sbu = (Sbu) context.getBean("sbu");

		Scanner sc = new Scanner(System.in);
		System.out.print("Employee ID : 	");
		int id = sc.nextInt();

		List<Object> eList = sbu.getEmplist()
			.stream()
			.filter(e -> ((Employee) e).getIds() == id)
			.collect(Collectors.toList());

		eList.forEach(e -> System.out.print("Employee Info:\n" +
				"Employee ID          : " + ((Employee) e).getIds() +
				"\nEmplpoyee NAME       : " + ((Employee) e).getName() +
				"\nEmployee SALARY      : " + ((Employee) e).getSalary()));
	}
}
