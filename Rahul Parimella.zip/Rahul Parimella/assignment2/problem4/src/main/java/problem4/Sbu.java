package problem4;
import java.util.List;
public class Sbu {
	private String sbucode;
	private String sbuHead;
	private String sbuName;
	private List<Employee> emplist;
	@Override
	public String toString() {
		System.out.println("SBU details\n");
		System.out.println("--------------\n");
		return  " [sbucode=" + sbucode + ", sbuHead=" + sbuHead + ", sbuName=" + sbuName + ",Employee details-----> =" + emplist + "]";
	}
	public List<Employee> getEmplist() {
		return emplist;
	}
	public void setEmplist(List<Employee> emplist) {
		this.emplist = emplist;
	}
	public Sbu() {
		super();
	}
	public String getSbucode() {
		return sbucode;
	}
	public void setSbucode(String sbucode) {
		this.sbucode = sbucode;
	}
	public String getSbuHead() {
		return sbuHead;
	}
	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}
	public String getSbuName() {
		return sbuName;
	}
	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}
}
