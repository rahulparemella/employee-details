package entities;

import org.springframework.context.ApplicationContext;


import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

		// TODO Auto-generated method stub
		public static void main(String[] args) {
			ApplicationContext context = new ClassPathXmlApplicationContext("rahul2.xml");
	        Employee empObj = (Employee) context.getBean("employee");
	        empObj.showResult();
	        empObj.getSbuDetails();
		}
	}

